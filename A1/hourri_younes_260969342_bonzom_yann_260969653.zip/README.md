Author 1: Younes Hourri, 260969342  
Author 2: Yann Bonzom, 260969653  

Assignment uses starter code: YES  

**Author Notes on Question 1.2.3 my_ls:**  
The file ordering is done first based on alphabetical order of each character (ex. a comes before B, i.e., it is case-insensitive), and if they happen to be the same letter, we order them based on capitalization with lowercase coming before uppercase (ex. mysh is before Makefile). Punctuation such as '.' is compared with other characters using its ASCII value. 
