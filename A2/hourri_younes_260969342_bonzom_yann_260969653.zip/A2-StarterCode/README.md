Author 1: Younes Hourri, 260969342  
Author 2: Yann Bonzom, 260969653  

Assignment used our own assignment 1 solution.
