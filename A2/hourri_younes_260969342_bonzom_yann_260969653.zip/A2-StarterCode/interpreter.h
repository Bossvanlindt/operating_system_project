int interpreter(char* command_args[], int args_size);
int badcommandFileDoesNotExist();
int badcommand();
int help();