//2.2.1
int kernel(char *file1, char *file2, char *file3, char *policy);
