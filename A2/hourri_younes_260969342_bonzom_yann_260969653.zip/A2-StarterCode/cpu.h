//2.2.1
int cpu_run(int start_location, int end_location);
int cpu_run_lines(int current_location, int end_location, int num_lines);
